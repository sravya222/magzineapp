const { S3Client, ListObjectsV2Command, PutObjectCommand } = require('@aws-sdk/client-s3');

const BUCKET_NAME = 'devmedialandrevenue';
const REGION = 'ap-south-2';

const s3Client = new S3Client({ region: REGION });

const MONTH_ORDER = [
  'january', 'february', 'march', 'april', 'may', 'june',
  'july', 'august', 'september', 'october', 'november', 'december'
];

exports.handler = async () => {
  try {
    const yearMap = {}; // dynamic year map
    const allCovers = [];

    let continuationToken;
    do {
      const listParams = {
        Bucket: BUCKET_NAME,
        ContinuationToken: continuationToken,
      };

      const data = await s3Client.send(new ListObjectsV2Command(listParams));
      const contents = data.Contents || [];

      for (const item of contents) {
        const key = item.Key;
        const match = key.match(/^(\d{4})\/([a-z]+)\/.*(cover.*)\.(jpg|jpeg|png|webp)$/i);

        if (match) {
          const year = match[1];
          const month = match[2].toLowerCase();
          const url = `https://s3.ap-south-2.amazonaws.com/${BUCKET_NAME}/${key}`;
          const _id = `${month}-${year}`;
          const yearKey = `year${year}`;

          const entry = { _id, coverImage: url };

          if (!yearMap[yearKey]) {
            yearMap[yearKey] = [];
          }

          yearMap[yearKey].push(entry);
          allCovers.push(entry);
        }
      }

      continuationToken = data.IsTruncated ? data.NextContinuationToken : undefined;
    } while (continuationToken);

    // Sort each year’s array descending by month
    Object.keys(yearMap).forEach(yearKey => {
      yearMap[yearKey].sort((a, b) => {
        const [monthA] = a._id.split('-');
        const [monthB] = b._id.split('-');
        return MONTH_ORDER.indexOf(monthB) - MONTH_ORDER.indexOf(monthA);
      });
    });

    // Sort all covers for latestSlides
    const latestSlides = [...allCovers].sort((a, b) => {
      const [monthA, yearA] = a._id.split('-');
      const [monthB, yearB] = b._id.split('-');
      if (yearA !== yearB) return parseInt(yearB) - parseInt(yearA);
      return MONTH_ORDER.indexOf(monthB) - MONTH_ORDER.indexOf(monthA);
    }).slice(0, 4);

    // Get reels
    const reels = [];
    const reelData = await s3Client.send(new ListObjectsV2Command({
      Bucket: BUCKET_NAME,
      Prefix: 'reels/'
    }));

    (reelData.Contents || []).forEach(item => {
      if (item.Key.endsWith('.mp4')) {
        const fileName = item.Key.split('/').pop().replace('.mp4', '');
        reels.push({
          _id: fileName,
          reelCover: `https://s3.ap-south-2.amazonaws.com/${BUCKET_NAME}/${item.Key}`
        });
      }
    });

    const output = {
      ...yearMap,
      latestSlides,
      reels
    };

    await s3Client.send(new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: 'json/dashboard.json',
      Body: JSON.stringify(output, null, 2),
      ContentType: 'application/json'
    }));

    console.log("✅ dashboard.json generated successfully");

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'dashboard.json updated', years: Object.keys(yearMap).length })
    };

  } catch (err) {
    console.error("❌ Error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message || 'Unexpected failure' }),
    };
  }
};
