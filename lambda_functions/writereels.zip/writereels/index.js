const { S3Client, ListObjectsV2Command, PutObjectCommand } = require('@aws-sdk/client-s3');

const BUCKET_NAME = 'devmedialandrevenue';
const REGION = 'ap-south-2';

const s3Client = new S3Client({ region: REGION });

exports.handler = async () => {
  try {
    const allReels = [];
    let continuationToken;

    do {
      const data = await s3Client.send(new ListObjectsV2Command({
        Bucket: BUCKET_NAME,
        Prefix: 'reels/',
        ContinuationToken: continuationToken,
      }));

      const contents = data.Contents || [];
      const videos = contents
        .filter(item => item.Key && item.Key.endsWith('.mp4'))
        .map(item => {
          const filename = item.Key.split('/').pop();       // e.g., "reel12.mp4"
          const _id = filename.replace('.mp4', '');          // e.g., "reel12"
          return {
            _id,
            url: `https://s3.ap-south-2.amazonaws.com/${BUCKET_NAME}/${item.Key}`,
          };
        });

      allReels.push(...videos);
      continuationToken = data.IsTruncated ? data.NextContinuationToken : undefined;

    } while (continuationToken);

    // Optional: Stable sort (e.g., reel2 before reel10)
    allReels.sort((a, b) =>
      a._id.localeCompare(b._id, undefined, { numeric: true, sensitivity: 'base' })
    );

    // Write to json/reels.json
    await s3Client.send(new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: 'json/reels.json',
      Body: JSON.stringify(allReels, null, 2),
      ContentType: 'application/json',
    }));

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Successfully saved reels.json', count: allReels.length }),
    };

  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message || 'Unexpected error' }),
    };
  }
};
