const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');

const BUCKET_NAME = 'devmedialandrevenue';
const REGION = 'ap-south-2';
const DASHBOARD_KEY = 'json/dashboard.json';
const MAX_REELS = 10;

const s3 = new S3Client({ region: REGION });

exports.handler = async () => {
  try {
    const data = await s3.send(new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: DASHBOARD_KEY,
    }));

    const body = await streamToString(data.Body);
    const dashboard = JSON.parse(body);

    const reels = Array.isArray(dashboard.reels) ? dashboard.reels : [];

    // Fisher–Yates shuffle (in-place), then take first 10
    for (let i = reels.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [reels[i], reels[j]] = [reels[j], reels[i]];
    }
    dashboard.reels = reels.slice(0, Math.min(MAX_REELS, reels.length));

    return {
      statusCode: 200,
      body: JSON.stringify(dashboard),
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    };
  } catch (err) {
    console.error('Error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message || 'Failed to read dashboard.json' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
};

function streamToString(stream) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    stream.on('data', c => chunks.push(c));
    stream.on('error', reject);
    stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
  });
}
