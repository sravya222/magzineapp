const { S3Client, ListObjectsV2Command } = require('@aws-sdk/client-s3');

const BUCKET_NAME = 'devmedialandrevenue';
const REGION = 'ap-south-2';

const s3Client = new S3Client({ region: REGION });

exports.handler = async (event = {}) => {
    try {
        const params = {
            Bucket: BUCKET_NAME,
            Prefix: 'reels/',
        };

        let allReels = [];
        let isTruncated = true;
        let continuationToken = undefined;

        // Handle pagination to get all reels if there are more than 1000
        while (isTruncated) {
            const command = new ListObjectsV2Command({
                ...params,
                ContinuationToken: continuationToken
            });

            const data = await s3Client.send(command);

            if (data.Contents) {
                // Filter out "folder" objects (keys ending with '/')
                const filteredItems = data.Contents.filter(item => item.Key && !item.Key.endsWith('/'));

                allReels = allReels.concat(filteredItems.map(item => {
                    // Extract filename for _id, e.g., "reel1.mp4" -> "reel1"
                    const filename = item.Key.split('/').pop();
                    const _id = filename.split('.')[0];
                    return {
                        _id: _id,
                        url: `https://s3.ap-south-2.amazonaws.com/${BUCKET_NAME}/${item.Key}`,
                        // url: `https://${BUCKET_NAME}/${item.Key}`,
                    };
                }));
            }

            isTruncated = data.IsTruncated;
            continuationToken = data.NextContinuationToken;
        }

        // --- Core Logic for Dynamic Order (Random Shuffle) ---
        // Shuffle the 'allReels' array randomly
        const shuffledReels = allReels.sort(() => 0.5 - Math.random());

        // You can limit the number of reels returned here if needed, e.g., take first 10
        // const finalReels = shuffledReels.slice(0, 10); // Uncomment if you want to limit to 10

        return {
            statusCode: 200,
            body: JSON.stringify(shuffledReels), // Return the shuffled list
            headers: {
                'Content-Type': 'application/json',
                // 'Access-Control-Allow-Origin': '*', // Uncomment if enabling CORS
            },
        };
    } catch (error) {
        console.error("Error fetching reels:", error); // Log the full error
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message || 'Failed to fetch reels' }),
            headers: {
                'Content-Type': 'application/json',
            },
        };
    }
};