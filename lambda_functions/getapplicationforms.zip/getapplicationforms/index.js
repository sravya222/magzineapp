const { S3Client, ListObjectsV2Command } = require('@aws-sdk/client-s3');

const BUCKET_NAME = 'devmedialandrevenue';
const REGION = 'ap-south-2';

const s3Client = new S3Client({ region: REGION });

// Change the exported function name to 'handler'
exports.handler = async (event = {}) => {
    try {
        const params = {
            Bucket: BUCKET_NAME,
            Prefix: 'applicationforms/', // Specify the folder for application forms
        };

        let allApplicationForms = [];
        let isTruncated = true;
        let continuationToken = undefined;

        // Handle pagination to get all forms if there are more than 1000
        while (isTruncated) {
            const command = new ListObjectsV2Command({
                ...params,
                ContinuationToken: continuationToken
            });

            const data = await s3Client.send(command);

            if (data.Contents) {
                // Filter out "folder" objects (keys ending with '/') and ensure it's a PDF or relevant file type
                const filteredItems = data.Contents.filter(item => 
                    item.Key && 
                    !item.Key.endsWith('/') && 
                    item.Key.toLowerCase().endsWith('.pdf') // Assuming all application forms are PDFs
                );

                allApplicationForms = allApplicationForms.concat(filteredItems.map(item => {
                    // Extract filename for _id, e.g., "applicationforms/form1.pdf" -> "form1"
                    const filenameWithExtension = item.Key.split('/').pop();
                    const _id = filenameWithExtension.split('.')[0];
                    return {
                        _id: _id,
                        url: `https://${BUCKET_NAME}.s3.${REGION}.amazonaws.com/${item.Key}`,
                        // url: `https://${BUCKET_NAME}/${item.Key}`,
                    };
                }));
            }

            isTruncated = data.IsTruncated;
            continuationToken = data.NextContinuationToken;
        }

        return {
            statusCode: 200,
            body: JSON.stringify(allApplicationForms), // Return the list of application forms
            headers: {
                'Content-Type': 'application/json',
                // Add CORS headers if your API Gateway needs them
                // 'Access-Control-Allow-Origin': '*',
                // 'Access-Control-Allow-Methods': 'GET',
                // 'Access-Control-Allow-Headers': 'Content-Type',
            },
        };
    } catch (error) {
        console.error("Error fetching application forms:", error); // Log the full error
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message || 'Failed to fetch application forms' }),
            headers: {
                'Content-Type': 'application/json',
            },
        };
    }
};