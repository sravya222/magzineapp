const { S3Client, ListObjectsV2Command, PutObjectCommand } = require('@aws-sdk/client-s3'); // Import PutObjectCommand

const BUCKET_NAME = 'devmedialandrevenue';
const S3_BUCKET_REGION = 'ap-south-2'; // Explicitly set to your bucket's actual region

const s3Client = new S3Client({ region: S3_BUCKET_REGION });

exports.handler = async (event = {}) => {
    try {
        // Support both API Gateway (event.queryStringParameters) and direct call (event.id)
        const id = event.queryStringParameters?.id || event.id;
        if (!id || typeof id !== 'string') {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'ID parameter is required' }),
            };
        }

        const [month, year] = id.split('-');
        if (!month || !year) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Invalid ID format. Expected format: month-year (e.g., april-2025)' }),
            };
        }

        const baseId = `${month}-${year}`;

        // --- Fetch and process main folder contents (for PDF and images) ---
        const mainFolderPrefix = `${year}/${month}/`; // Corrected based on your current example: 2025/april/
        const mainFolderParams = { Bucket: BUCKET_NAME, Prefix: mainFolderPrefix };
        const mainFolderData = await s3Client.send(new ListObjectsV2Command(mainFolderParams));
        const mainFolderContents = mainFolderData.Contents || [];

        // Find PDF
        const pdfObj = mainFolderContents.find(item => item.Key?.endsWith('.pdf'));
        const pdfArr = pdfObj
            ? [{ _id: `${baseId}-pdf`, url: `https://s3.ap-south-2.amazonaws.com/${BUCKET_NAME}/${pdfObj.Key}` }]
            : [];

        // Find and sort images (exclude pdfs, folders, and 'cover' images)
        const images = mainFolderContents
            .filter(item =>
                item.Key &&
                !item.Key.endsWith('.pdf') &&
                !item.Key.endsWith('/') && // Exclude folders
                !item.Key.toLowerCase().includes('cover') &&
                /\.(jpg|jpeg|png|gif|webp)$/i.test(item.Key) // Ensure it's an image
            )
            // Sort the images based on the number in their filename
            .sort((a, b) => {
                const fileNameA = a.Key.split('/').pop();
                const fileNameB = b.Key.split('/').pop();

                const numA = parseInt(fileNameA.match(/(\d+)\./)?.[1] || '0', 10);
                const numB = parseInt(fileNameB.match(/(\d+)\./)?.[1] || '0', 10);

                return numA - numB; // Sort in ascending order
            })
            .map((item, idx) => ({
                _id: `${baseId}-image${idx + 1}`,
                url: `https://s3.ap-south-2.amazonaws.com/${BUCKET_NAME}/${item.Key}`
            }));
        
        const finalImages = images; // No reels, so direct assignment

        // --- Prepare and Upload JSON to S3 ---
        const outputData = { pdf: pdfArr, images: finalImages };
        const jsonBody = JSON.stringify(outputData, null, 2); // Pretty print with 2 spaces

        // Define the S3 key for the JSON file
        const s3JsonKey = `json/${year}/${month}/${month}-${year}-images.json`; 

        const putObjectParams = {
            Bucket: BUCKET_NAME,
            Key: s3JsonKey,
            Body: jsonBody,
            ContentType: 'application/json' // Important for S3 to serve it correctly
        };

        console.log(`Attempting to upload JSON to S3: s3://${BUCKET_NAME}/${s3JsonKey}`);

        try {
            await s3Client.send(new PutObjectCommand(putObjectParams));
            console.log(`Successfully uploaded ${s3JsonKey} to S3.`);
        } catch (uploadError) {
            console.error("Error uploading JSON to S3:", uploadError);
            // Decide how to handle upload failure:
            // 1. Throw the error to indicate overall failure, or
            // 2. Just log it and proceed with returning the data.
            // For now, we'll just log and proceed.
        }

        // --- Return the JSON data as the Lambda response ---
        return {
            statusCode: 200,
            body: JSON.stringify(outputData), // Return the same data that was uploaded
        };
    } catch (error) {
        console.error("Error fetching or processing data:", error); // Log the error for debugging
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message || 'Failed to fetch or process data' }),
        };
    }
};