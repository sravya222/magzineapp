const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');

const BUCKET_NAME = 'devmedialandrevenue';
const REGION = 'ap-south-2';

const s3Client = new S3Client({ region: REGION });

exports.handler = async (event = {}) => {
  try {
    const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;

    const { name = '', email = '', content = '' } = body || {};

    const feedback = {
      name,
      email,
      content,
      submittedAt: new Date().toISOString(),
    };

    const fileName = `feedback/feedback-${Date.now()}.json`;

    const params = {
      Bucket: BUCKET_NAME,
      Key: fileName,
      Body: JSON.stringify(feedback, null, 2),
      ContentType: 'application/json',
    };

    await s3Client.send(new PutObjectCommand(params));

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Feedback saved successfully' }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message || 'Failed to save feedback' }),
    };
  }
};
