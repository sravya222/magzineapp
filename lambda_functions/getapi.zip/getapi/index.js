exports.handler = async () => {
  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Magazine Lambda API Docs</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist/swagger-ui.css" />
  <style>
    html { box-sizing: border-box; overflow: -moz-scrollbars-vertical; overflow-y: scroll; }
    *, *:before, *:after { box-sizing: inherit; }
    body { margin: 0; background: #fafafa; }
  </style>
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist/swagger-ui-bundle.js"></script>
  <script>
    window.onload = function() {
      const spec = {
        openapi: '3.0.0',
        info: {
          title: 'Magazine Lambda API',
          version: '1.0.0',
          description: 'API documentation for the Magazine Lambda endpoints',
        },
        servers: [
          {
            url: 'https://xsm2xb1ymi.execute-api.ap-south-2.amazonaws.com/dev',
          },
        ],
        paths: {
          '/reels': {
            get: {
              summary: 'Get all reels',
              description: 'Returns a list of all reels from the S3 bucket under the reels/ prefix.',
              tags: ['Lambda'],
              responses: {
                200: {
                  description: 'A list of reels',
                  content: {
                    'application/json': {
                      schema: {
                        type: 'array',
                        items: {
                          type: 'object',
                          properties: {
                            _id: { type: 'string', example: 'reel1' },
                            url: { type: 'string', example: 'https://tsrmagazine.s3.ap-south-1.amazonaws.com/reels/reel1.mp4' },
                          },
                        },
                      },
                    },
                  },
                },
                500: { description: 'Failed to fetch reels' },
              },
            },
          },
          '/magazine': {
            get: {
              summary: 'Get magazine PDF and images',
              description: 'Returns the PDF and images for a given year and month. Query param: id=month-year',
              tags: ['Lambda'],
              parameters: [
                {
                  name: 'id',
                  in: 'query',
                  required: true,
                  schema: { type: 'string', example: 'april-2025' },
                  description: 'Magazine ID in the format year-month',
                },
              ],
              responses: {
                200: {
                  description: 'Magazine PDF and images',
                  content: {
                    'application/json': {
                      schema: {
                        type: 'object',
                        properties: {
                          pdf: {
                            type: 'array',
                            items: {
                              type: 'object',
                              properties: {
                                _id: { type: 'string', example: 'april-2025-pdf' },
                                url: { type: 'string', example: 'https://tsrmagazine.s3.ap-south-1.amazonaws.com/2025/april/april.pdf' },
                              },
                            },
                          },
                          images: {
                            type: 'array',
                            items: {
                              type: 'object',
                              properties: {
                                _id: { type: 'string', example: 'april-2025-image1' },
                                url: { type: 'string', example: 'https://tsrmagazine.s3.ap-south-1.amazonaws.com/2025/april/image1.jpg' },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                400: { description: 'Invalid or missing ID' },
                500: { description: 'Failed to fetch magazine' },
              },
            },
          },
          '/dashboard': {
            get: {
              summary: 'Get dashboard data',
              description: 'Returns the dashboard.json content from S3.',
              tags: ['Lambda'],
              responses: {
                200: {
                  description: 'Dashboard data',
                  content: {
                    'application/json': {
                      schema: { type: 'object' },
                    },
                  },
                },
                404: { description: 'dashboard.json not found' },
                500: { description: 'Failed to fetch dashboard' },
              },
            },
          },
          '/feedback': {
            post: {
              summary: 'Submit feedback',
              description: 'Saves user feedback (name, email, content) to S3 as a JSON file.',
              tags: ['Lambda'],
              requestBody: {
                required: true,
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        name: { type: 'string', example: 'John Doe' },
                        email: { type: 'string', example: 'john@example.com' },
                        content: { type: 'string', example: 'Great magazine!' },
                      },
                      required: ['name', 'email', 'content'],
                    },
                  },
                },
              },
              responses: {
                200: {
                  description: 'Feedback saved successfully',
                  content: {
                    'application/json': {
                      schema: {
                        type: 'object',
                        properties: {
                          message: { type: 'string', example: 'Feedback saved successfully' },
                        },
                      },
                    },
                  },
                },
                500: {
                  description: 'Failed to save feedback',
                  content: {
                    'application/json': {
                      schema: {
                        type: 'object',
                        properties: {
                          error: { type: 'string', example: 'Failed to save feedback' },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          '/faq': { // Added FAQ endpoint
            get: {
              summary: 'Get Frequently Asked Questions',
              description: 'Returns a list of frequently asked questions and their answers from an S3 bucket (e.g., faq.json).',
              tags: ['Lambda'],
              responses: {
                200: {
                  description: 'A list of FAQs',
                  content: {
                    'application/json': {
                      schema: {
                        type: 'array',
                        items: {
                          type: 'object',
                          properties: {
                            _id: { type: 'string', example: 'question-1' },
                            question: { type: 'string', example: 'How can I check the status of my application?' },
                            answer: { type: 'string', example: 'The status of applications can be checked through the ‘e Challan /Application Status’ module at https://bhubharati.telangana.gov.in/ApplicationStatus.' }
                          },
                          required: ['_id', 'question', 'answer']
                        },
                        example: [
                            {
                                "_id": "question-1",
                                "question": "How can I check the status of my application?",
                                "answer": "The status of applications can be checked through the ‘e Challan /Application Status’ module at https://bhubharati.telangana.gov.in/ApplicationStatus."
                            },
                            {
                                "_id": "question-2",
                                "question": "Where does the property registration process take place?",
                                "answer": "Registration will be done at the Tahsildar cum Joint Sub Registrar Office as indicated in the slot booking receipt."
                            }
                        ]
                      },
                    },
                  },
                },
                500: {
                  description: 'Failed to fetch FAQs',
                  content: {
                    'application/json': {
                      schema: {
                        type: 'object',
                        properties: {
                          error: { type: 'string', example: 'Failed to retrieve FAQ data from S3.' },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          '/usermanuals': { // Added User Manuals endpoint documentation
            get: {
              summary: 'Get all user manuals',
              description: 'Returns a list of all user manuals (e.g., PDFs) from the S3 bucket under the usermanuals/ prefix.',
              tags: ['Lambda'],
              responses: {
                200: {
                  description: 'A list of user manuals',
                  content: {
                    'application/json': {
                      schema: {
                        type: 'array',
                        items: {
                          type: 'object',
                          properties: {
                            _id: { type: 'string', example: 'setup-guide' },
                            url: { type: 'string', example: 'https://tsrmagazine.s3.ap-south-1.amazonaws.com/usermanuals/setup-guide.pdf' },
                          },
                          required: ['_id', 'url']
                        },
                        example: [
                            {
                                "_id": "quick-start-manual",
                                "url": "https://tsrmagazine.s3.ap-south-1.amazonaws.com/usermanuals/quick-start-manual.pdf"
                            },
                            {
                                "_id": "advanced-config-manual",
                                "url": "https://tsrmagazine.s3.ap-south-1.amazonaws.com/usermanuals/advanced-config-manual.pdf"
                            }
                        ]
                      },
                    },
                  },
                },
                500: {
                  description: 'Failed to fetch user manuals',
                  content: {
                    'application/json': {
                      schema: {
                        type: 'object',
                        properties: {
                          error: { type: 'string', example: 'Failed to retrieve user manuals from S3.' },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      };

      const ui = SwaggerUIBundle({
        spec,
        dom_id: '#swagger-ui',
      });
    };
  </script>
</body>
</html>
  `;

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'text/html' },
    body: html,
  };
};