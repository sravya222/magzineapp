const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { Readable } = require('stream');

const BUCKET_NAME = 'devmedialandrevenue';
const REGION = 'ap-south-2';
const MAX_REELS_TO_INSERT = 5;
const MIN_IMAGES_BETWEEN_REELS = 3;

const s3Client = new S3Client({ region: REGION });

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function getRandomUniqueIndicesWithGap(minVal, maxVal, count, minGap) {
  const availableRange = maxVal - minVal + 1;
  const requiredSpots = count > 0 ? count + (count - 1) * minGap : 0;

  if (requiredSpots > availableRange) {
    count = Math.floor((availableRange + minGap) / (1 + minGap));
    if (count <= 0) return [];
  }

  const possibleIndices = Array.from({ length: availableRange }, (_, i) => minVal + i);
  shuffleArray(possibleIndices);

  const selectedIndices = [];
  for (const candidate of possibleIndices) {
    if (selectedIndices.every(i => Math.abs(i - candidate) > minGap)) {
      selectedIndices.push(candidate);
      if (selectedIndices.length === count) break;
    }
  }

  return selectedIndices.sort((a, b) => b - a);
}

async function getJsonFromS3(key) {
  const command = new GetObjectCommand({
    Bucket: BUCKET_NAME,
    Key: key,
  });
  const response = await s3Client.send(command);
  const stream = response.Body;
  const bodyContents = await streamToString(stream);
  return JSON.parse(bodyContents);
}

function streamToString(stream) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    stream.on('data', (chunk) => chunks.push(chunk));
    stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
    stream.on('error', reject);
  });
}

exports.handler = async (event = {}) => {
  try {
    const id = event.queryStringParameters?.id || event.id;
    if (!id || typeof id !== 'string') {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing or invalid ID format.' }),
      };
    }

    const [month, year] = id.split('-');
    if (!month || !year) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'ID format must be: <month>-<year>' }),
      };
    }

    const jsonKey = `json/${year}/${month}/${month}-${year}-images.json`;
    const reelsKey = `json/reels.json`;

    const [imageData, reelsData] = await Promise.all([
      getJsonFromS3(jsonKey),
      getJsonFromS3(reelsKey),
    ]);

    const images = imageData.images || [];
    const pdf = imageData.pdf || [];

    if (images.length === 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({ pdf, images: [] }),
      };
    }

    const availableReels = shuffleArray(reelsData).slice(0, MAX_REELS_TO_INSERT);
    let finalImages = [...images];

    if (availableReels.length > 0) {
      const minInsertIndex = 1;
      const maxInsertIndex = finalImages.length - 1;
      const insertionPoints = getRandomUniqueIndicesWithGap(
        minInsertIndex,
        maxInsertIndex,
        availableReels.length,
        MIN_IMAGES_BETWEEN_REELS
      );

      for (let i = 0; i < insertionPoints.length; i++) {
        const insertIndex = insertionPoints[i];
        finalImages.splice(insertIndex, 0, availableReels[i]);
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ pdf, images: finalImages }),
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    };
  } catch (err) {
    console.error('Error merging json + reels:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message || 'Server error' }),
    };
  }
};
