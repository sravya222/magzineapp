const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { Readable } = require('stream');

const BUCKET_NAME = 'devmedialandrevenue';
const REGION = 'ap-south-2';

const s3Client = new S3Client({ region: REGION });

async function streamToString(stream) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        stream.on('data', (chunk) => chunks.push(chunk));
        stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
        stream.on('error', reject);
    });
}

exports.handler = async (event = {}) => {
    try {
        const params = {
            Bucket: BUCKET_NAME,
            Key: 'faq.json',
        };

        const data = await s3Client.send(new GetObjectCommand(params));

        if (!data.Body) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'faq.json not found or empty' }),
            };
        }

        const jsonString = await streamToString(data.Body);
        const faqData = JSON.parse(jsonString);

        return {
            statusCode: 200,
            body: JSON.stringify(faqData),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message || 'Failed to fetch faq' }),
        };
    }
};
